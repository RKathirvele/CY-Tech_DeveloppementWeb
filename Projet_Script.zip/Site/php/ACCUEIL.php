<?php

require_once('varSession.inc.php');
require_once('session_start.inc.php');
// Accéder aux variables de session et les utiliser
// ...

?>