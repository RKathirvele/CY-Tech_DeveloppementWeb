// script.js

document.addEventListener('DOMContentLoaded', function() {
  let images = document.querySelectorAll('.zoomable');

  images.forEach(function(image) {
      image.addEventListener('click', function() {
          this.classList.toggle('zoomed');
      });
  });

  // Ajout d'un gestionnaire d'événements pour les boutons "Ajouter au panier"
  let addToCartButtons = document.querySelectorAll('.add-to-cart');
  addToCartButtons.forEach(function(button) {
      button.addEventListener('click', function(event) {
          event.preventDefault(); // Empêcher le comportement par défaut du lien

          // Récupérer les informations du produit
          let productName = this.parentElement.querySelector('h3').innerText;
          let price = parseFloat(this.parentElement.querySelector('p').innerText.split(' ')[1]); // Récupérer le prix

          // Appeler la fonction addToCart avec les informations du produit
          addToCart(productName, 1, price);
      });
  });
});



// Fonction pour ajouter le produit au panier
function addToCart(productName, quantity, price) {
    // Créer un objet représentant le produit à ajouter au panier
    let quantity = parseInt(document.getElementById('quantity').value);

    let product = {
      name: productName,
      quantity: quantity,
      price: price
    };
  
    // Récupérer le panier depuis le stockage local s'il existe, sinon initialiser un panier vide
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
  
    // Vérifier si le produit est déjà dans le panier
    let existingProductIndex = cart.findIndex(item => item.name === product.name);
  
    if (existingProductIndex !== -1) {
      // Si le produit existe déjà dans le panier, mettre à jour la quantité
      cart[existingProductIndex].quantity += product.quantity;
    } else {
      // Sinon, ajouter le produit au panier
      cart.push(product);
    }
  
    // Mettre à jour le panier dans le stockage local
    localStorage.setItem('cart', JSON.stringify(cart));
  
    // Afficher un message de confirmation ou mettre à jour l'interface utilisateur
    alert('Le produit a été ajouté au panier !');
}



// Fonction pour valider et soumettre le formulaire
function validateAndSubmitForm() {
  // Vérification du formulaire
  if (validateForm()) {
    // Si le formulaire est valide, rediriger vers contactconf.html
    window.location.href = "../html/contactconf.html";
  } else {
    // Sinon, afficher un message d'erreur
    alert("Veuillez remplir tous les champs du formulaire.");
  }
}

// Fonction pour vérifier le formulaire de contact
function validateForm() {
  let nomInput = document.getElementById('nom');
  let emailInput = document.getElementById('email');
  let messageInput = document.getElementById('message');
  let isValid = true;

  // Vérification du nom
  if (nomInput.value === '') {
    nomInput.style.borderColor = 'red';
    isValid = false;
  } else {
    nomInput.style.borderColor = '';
  }

  // Vérification de l'e-mail
  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(emailInput.value)) {
    emailInput.style.borderColor = 'red';
    isValid = false;
  } else {
    emailInput.style.borderColor = '';
  }

  // Vérification du message
  if (messageInput.value === '') {
    messageInput.style.borderColor = 'red';
    isValid = false;
  } else {
    messageInput.style.borderColor = '';
  }

  return isValid;
}


document.getElementById('toggleStock').addEventListener('click', function() {
  let stockCells = document.querySelectorAll('.stock');
  stockCells.forEach(function(cell) {
    cell.classList.toggle('hidden');
  });
});

document.getElementById('productList').addEventListener('click', function(event) {
  if (event.target.tagName === 'A') {
    event.preventDefault();
    addToCart();
  }
});

document.querySelector('form').addEventListener('submit', function(event) {
  if (!validateForm()) {
    event.preventDefault();
  }
});



// Fonction pour récupérer la quantité d'un produit
function getQuantity(productId) {
  let quantityInput = document.getElementById(`quantity${productId}`);
  return parseInt(quantityInput.value) || 0;
}

// Fonction pour mettre à jour la quantité d'un produit
function updateQuantity(productId, newQuantity) {
  let quantityInput = document.getElementById(`quantity${productId}`);
  quantityInput.value = newQuantity;
}


// Sélectionner tous les boutons d'augmentation de quantité
const boutonsIncrementation = document.querySelectorAll('.increase');
const boutonsDecrementation = document.querySelectorAll('.decrease');

// Ajouter un écouteur d'événement clic à chaque bouton
boutonsIncrementation.forEach(bouton => {
  bouton.addEventListener('click', function() {
    // Obtenir le champ de saisie de quantité associé
    const champQuantite = this.parentElement.querySelector('.quantity');
    
    // Obtenir la valeur de quantité actuelle (en supposant que c'est un nombre)
    let valeurQuantite = parseInt(champQuantite.value);
    
    // Incrémenter la valeur de quantité (en supposant qu'une limite de stock n'est pas appliquée)
    if (valeurQuantite<20) {
        valeurQuantite++;
    }
    
    // Mettre à jour le champ de saisie de quantité avec la nouvelle valeur
    champQuantite.value = valeurQuantite;
  });
});


// Ajouter un écouteur d'événement clic à chaque bouton
boutonsDecrementation.forEach(bouton => {
    bouton.addEventListener('click', function() {
      // Obtenir le champ de saisie de quantité associé
      const champQuantite = this.parentElement.querySelector('.quantity');
      
      // Obtenir la valeur de quantité actuelle (en supposant que c'est un nombre)
      let valeurQuantite = parseInt(champQuantite.value);
      
      // Incrémenter la valeur de quantité (en supposant qu'une limite de stock n'est pas appliquée)
      
      if (valeurQuantite>0) {
        valeurQuantite--;
    }
      
      // Mettre à jour le champ de saisie de quantité avec la nouvelle valeur
      champQuantite.value = valeurQuantite;
    });
  });