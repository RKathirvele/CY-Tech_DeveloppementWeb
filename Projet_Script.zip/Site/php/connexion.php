<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chocolaterie La Gourmandise</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  <header>
    <h1>Chocolaterie La Gourmandise</h1>
    <img src="../img/logo.png" alt="Logo de la Chocolaterie La Gourmandise" width="200" height="200">
  </header>
<body>
  <h1>Connexion</h1>
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="username">Nom d'utilisateur:</label>
    <input type="text" id="username" name="username" required>
    <br>
    <label for="password">Mot de passe:</label>
    <input type="password" id="password" name="password" required>
    <br>
    <button type="submit">Se connecter</button>
  </form>
</body>
</html>



<?php

$hote = "localhost"; // Remplacer par l'hôte de votre base de données
$nom_base = "login"; // Remplacer par le nom de votre base de données
$utilisateur = "root"; // Remplacer par l'utilisateur de votre base de données
$mot_de_passe = "cytech0001"; // Remplacer par le mot de passe de votre base de données

try {
  $conn = new PDO("mysql:host=$hote;dbname=$nom_base", $utilisateur, $mot_de_passe);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  echo "Échec de la connexion : " . $e->getMessage();
  die(); // Arrêter l'exécution en cas d'erreur de connexion
}

// Démarrage de la session pour stocker les informations utilisateur
session_start();

// Traitement du formulaire de connexion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nom_utilisateur = trim($_POST["username"]);
  $mot_de_passe = trim($_POST["password"]);

  // Préparer la requête SQL pour récupérer l'utilisateur par nom d'utilisateur
  $sql = "SELECT * FROM utilisateur WHERE nom_utilisateur = :nom_utilisateur";
  $stmt = $conn->prepare($sql);
  $stmt->bindParam(":nom_utilisateur", $nom_utilisateur);
  $stmt->execute();	

  $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);
  
  $sql1 = "SELECT mot_de_passe FROM utilisateur WHERE nom_utilisateur = :nom_utilisateur";
  $stmt1 = $conn->prepare($sql);
  $stmt1->bindParam(":nom_utilisateur", $nom_utilisateur);
  $stmt1->execute();	

  $mdp = $stmt->fetch(PDO::FETCH_ASSOC);
  if ($utilisateur && ($mot_de_passe==$utilisateur["mot_de_passe"])) {
    // Utilisateur authentifié, stocker les informations dans la session
    $_SESSION["id_utilisateur"] = $utilisateur["id"];
    $_SESSION["nom_utilisateur"] = $nom_utilisateur;
    header("Location: ../Accueil.html"); // Redirection vers la page d'accueil
    die(); // Arrêter l'exécution après la redirection
  } else {
    echo "<p class='erreur'>Erreur de connexion, nom d'utilisateur ou mot de passe incorrect.</p>";
  }
}
?>
