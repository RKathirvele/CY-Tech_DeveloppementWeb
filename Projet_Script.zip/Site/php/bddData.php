<?php

// Connexion à la base de données (remplacez les informations de connexion par les vôtres)
$db = new mysqli('localhost', 'utilisateur', 'mot_de_passe', 'nom_base_de_données');

// Vérifier la connexion
if ($db->connect_error) {
    die('Erreur de connexion à la base de données : ' . $db->connect_error);
}

// Parcourir les éléments de liste des produits
$produits = [];
$categories = []; // Tableau pour stocker les catégories uniques

$listeProduits = $document->getElementsByTagName('li'); // Supposons que $document est l'objet DOM représentant le code HTML
foreach ($listeProduits as $produitElement) {
    // Extraire les informations du produit
    $nomProduit = $produitElement->getElementsByTagName('h3')[0]->textContent;
    $descriptionProduit = $produitElement->getElementsByTagName('p')[1]->textContent;
    $prixProduit = (float) str_replace('€', '', $produitElement->getElementsByTagName('p')[2]->textContent);
    $imageProduit = $produitElement->getElementsByTagName('img')[0]->getAttribute('src');
    $stockProduit = (int) $produitElement->getElementsByTagName('input')[0]->getAttribute('value');

    // Déterminer la catégorie du produit (à adapter en fonction de votre structure HTML)
    $categorieProduit = $produitElement->parentNode->parentNode->getElementsByTagName('h2')[0]->textContent; // Supposons que les produits sont regroupés par catégorie dans des sections `<h2>`

    // Stocker les informations du produit dans un tableau
    $produit = [
        'nom' => $nomProduit,
        'description' => $descriptionProduit,
        'prix' => $prixProduit,
        'image' => $imageProduit,
        'stock' => $stockProduit,
        'categorie' => $categorieProduit
    ];
    $produits[] = $produit;

    // Ajouter la catégorie à la liste des catégories uniques (si elle n'y est pas déjà)
    if (!in_array($categorieProduit, $categories)) {
        $categories[] = $categorieProduit;
    }
}

// Générer les requêtes INSERT pour les produits
foreach ($produits as $produit) {
    $categorieId = array_search($produit['categorie'], $categories) + 1; // Obtenir l'ID de catégorie correspondant
    $requeteInsertProduit = "INSERT INTO produits (nom, description, prix, image, stock, categorie_id) VALUES ('{$produit['nom']}', '{$produit['description']}', {$produit['prix']}, '{$produit['image']}', {$produit['stock']}, {$categorieId})";

    if ($db->query($requeteInsertProduit) === false) {
        echo "Erreur d'insertion du produit : $requeteInsertProduit<br>";
    } else {
        echo "Produit inséré avec succès : {$produit['nom']}<
