<footer>
  <p>&copy; 2024 Chocolaterie La Gourmandise</p>
  <a href="../html/contact.html">Contact</a>
</footer>
