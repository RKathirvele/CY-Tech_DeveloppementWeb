<header>
  <h1>Chocolaterie La Gourmandise</h1>
  <img src="../img/logo.png" alt="Logo de la Chocolaterie La Gourmandise" width="200" height="200">
</header>
