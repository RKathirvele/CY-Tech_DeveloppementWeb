<?php
// Fonction pour ajouter le produit au panier
function addToCart($productName, $quantity, $price) {
    // Créer un objet représentant le produit à ajouter au panier
    $quantity = intval($_POST['quantity']);

    $product = array(
        'name' => $productName,
        'quantity' => $quantity,
        'price' => $price
    );

    // Récupérer le panier depuis le stockage local s'il existe, sinon initialiser un panier vide
    $cart = json_decode($_SESSION['cart'], true) ?: array();

    // Vérifier si le produit est déjà dans le panier
    $existingProductIndex = array_search($product['name'], array_column($cart, 'name'));

    if ($existingProductIndex !== false) {
        // Si le produit existe déjà dans le panier, mettre à jour la quantité
        $cart[$existingProductIndex]['quantity'] += $product['quantity'];
    } else {
        // Sinon, ajouter le produit au panier
        $cart[] = $product;
    }

    // Mettre à jour le panier dans le stockage local
    $_SESSION['cart'] = json_encode($cart);

    // Afficher un message de confirmation ou mettre à jour l'interface utilisateur
    echo 'Le produit a été ajouté au panier !';
}

// Fonction pour vérifier le formulaire de contact
function validateForm() {
    $nomInput = $_POST['nom'];
    $emailInput = $_POST['email'];
    $messageInput = $_POST['message'];
    $isValid = true;

    // Vérification du nom
    if ($nomInput === '') {
        $isValid = false;
    }

    // Vérification de l'email
    if (!filter_var($emailInput, FILTER_VALIDATE_EMAIL)) {
        $isValid = false;
    }

    // Vérification du message
    if ($messageInput === '') {
        $isValid = false;
    }

    return $isValid;
}

// Exemple d'utilisation de la fonction addToCart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['productName'], $_POST['quantity'], $_POST['price'])) {
    addToCart($_POST['productName'], $_POST['quantity'], $_POST['price']);
}
?>
