INSERT INTO categories (nom) VALUES ('Chocolat blanc');
INSERT INTO categories (nom) VALUES ('Chocolat au lait');
INSERT INTO categories (nom) VALUES ('Chocolat noir');

INSERT INTO produits (nom, description, prix, categorie_id, stock) VALUES ('Chocolat blanc aux noix','Un chocolat blanc onctueux et fondant, agrémenté de noix croquantes.', 10, 1, 20);
// Faire ça pour chaque produit...