// Sélectionner tous les boutons d'augmentation de quantité
const boutonsIncrementation = document.querySelectorAll('.increase');
const boutonsDecrementation = document.querySelectorAll('.decrease');

// Ajouter un écouteur d'événement clic à chaque bouton
boutonsIncrementation.forEach(bouton => {
  bouton.addEventListener('click', function() {
    // Obtenir le champ de saisie de quantité associé
    const champQuantite = this.parentElement.querySelector('.quantity');
    
    // Obtenir la valeur de quantité actuelle (en supposant que c'est un nombre)
    let valeurQuantite = parseInt(champQuantite.value);
    
    // Incrémenter la valeur de quantité (en supposant qu'une limite de stock n'est pas appliquée)
    if (valeurQuantite<20) {
        valeurQuantite++;
    }
    
    // Mettre à jour le champ de saisie de quantité avec la nouvelle valeur
    champQuantite.value = valeurQuantite;
  });
});


// Ajouter un écouteur d'événement clic à chaque bouton
boutonsDecrementation.forEach(bouton => {
    bouton.addEventListener('click', function() {
      // Obtenir le champ de saisie de quantité associé
      const champQuantite = this.parentElement.querySelector('.quantity');
      
      // Obtenir la valeur de quantité actuelle (en supposant que c'est un nombre)
      let valeurQuantite = parseInt(champQuantite.value);
      
      // Incrémenter la valeur de quantité (en supposant qu'une limite de stock n'est pas appliquée)
      
      if (valeurQuantite>0) {
        valeurQuantite--;
    }
      
      // Mettre à jour le champ de saisie de quantité avec la nouvelle valeur
      champQuantite.value = valeurQuantite;
    });
  });