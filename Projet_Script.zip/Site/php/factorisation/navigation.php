<header>
    <h1>Chocolaterie La Gourmandise</h1>
    <img src="../img/logo.png" alt="Logo de la Chocolaterie La Gourmandise" width="200" height="200">
    <nav>
        <ul>
            <li><a href="../ACCUEIL.html">Accueil</a></li>
            <li><a href="Blanc.html">Chocolat blanc</a></li>
            <li><a href="Lait.html">Chocolat au lait</a></li>
			<li><a href="noir.html">Chocolat noir</a></li>
			<li><a href="contact.html">Contact</a></li>
        </ul>
    </nav>
    <div class="header-icones"> <!-- Ajout de l'icone panier -->
      <a href="../html/panier.html" class="panier-icone">
        <img src="../img/panier.png" alt="Panier" width="200" height="200>
        <span class="panier-texte">Panier</span>
      </a>
    </div>
  </header>